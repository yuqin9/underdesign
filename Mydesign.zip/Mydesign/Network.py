from p4utils.mininetlib.network_API import NetworkAPI

net = NetworkAPI()
# include the API then we can make the topojson

net.setLogLevel('info')
net.setCompiler(p4rt = True)
net.execScript('python3 controller2_0.py', reboot=True)
net.addP4RuntimeSwitch('s1')
net.addP4RuntimeSwitch('s2')
net.enableCpuPort('s1')
net.enableCpuPort('s2')
net.enableArpTables()

net.setP4SourceAll('underdesign2_0.p4')
for i in range(1,4):
    hostname = 'h{}'.format(i)
    net.addHost(hostname)

# the h1 is the pc it will receive some others packets
# the Web server & the DNS Server is the object we decide to server
# a resourse sendhost
net.addHost('sendhost')
net.addHost('Webser')
net.addHost('DNSser')

net.addLink("sendhost","s1")
net.addLink("s1","h1")
net.addLink("s1","s2")
net.addLink("s1","Webser")
net.addLink("s2","h2")
net.addLink("s2","h3")
net.addLink("s2","DNSser")
net.addLink("s2","Webser")
# due to we have the host link to two sw so we can't use the l3 to automaticly set its ip
net.setIntfPort('sendhost', 's1', 0)  # Set the number of the port on s1 facing h1
net.setIntfPort('s1','sendhost',0)

net.setIntfPort('s1', 'h1', 1)  # Set the number of the port on h1 facing s1
net.setIntfPort('h1','s1', 1)

net.setIntfPort('s1', 'Webser', 2)  # Set the number of the port on s1 facing h2
net.setIntfPort('Webser','s1',  1)

net.setIntfPort('s1', 's2', 3)  # Set the number of the port on h2 facing s1
net.setIntfPort('s2', 's1',  3)

net.setIntfPort('s2', 'Webser', 0)  # Set the number of the port on s1 facing h3
net.setIntfPort('Webser', 's2', 0)

net.setIntfPort('s2', 'h2', 1)  # Set the number of the port on h3 facing s1
net.setIntfPort('h2','s2',  1)

net.setIntfPort('s2', 'h3', 2)  # Set the number of the port on s1 facing h4
net.setIntfPort('h3', 's2', 1)

net.setIntfPort('s2', 'DNSser', 4)  # Set the number of the port on h4 facing s1
net.setIntfPort('DNSser','s2',  1)
# ip&macaddr
# net.l3()
net.setIntfIp('sendhost','s1','10.0.0.9/24')
# in order to reduce the burden of work I decide to set the ip innet
net.setIntfIp('s1','h1','10.0.0.1/24')
net.setIntfIp('h1','s1','10.0.0.2/24')
net.setIntfIp('Webser','s1','10.0.0.3/24')
net.setIntfIp('s2','s1','10.0.0.4/24')
net.setIntfIp('Webser','s2','10.0.0.3/24')
net.setIntfIp('h2','s2','10.0.0.6/24')
net.setIntfIp('h3','s2','10.0.0.7/24')
net.setIntfIp('DNSser','s2','10.0.0.8/24')

net.setIntfMac('sendhost','s1','00:00:00:00:00:01')
net.setIntfMac('s1','sendhost','00:00:00:00:00:02')

net.setIntfMac('s1','h1','00:00:00:00:00:03')
net.setIntfMac('h1','s1','00:00:00:00:00:04')

net.setIntfMac('Webser','s1','00:00:00:00:00:05')
net.setIntfMac('s1','Webser','00:00:00:00:00:06')

net.setIntfMac('s2','s1','00:00:00:00:00:07')
net.setIntfMac('s1','s2','00:00:00:00:00:08')

net.setIntfMac('Webser','s2','00:00:00:00:00:09')
net.setIntfMac('s2','Webser','00:00:00:00:00:0a')

net.setIntfMac('h2','s2','00:00:00:00:00:0b')
net.setIntfMac('s2','h2','00:00:00:00:00:0c')

net.setIntfMac('h3','s2','00:00:00:00:00:0d')
net.setIntfMac('s2','h3','00:00:00:00:00:0e')

net.setIntfMac('DNSser','s2','00:00:00:00:00:11')
net.setIntfMac('s2','DNSser','00:00:00:00:00:12')
# Nodes general options
net.enablePcapDumpAll()
net.enableLogAll()
net.enableCli()
net.startNetwork()
