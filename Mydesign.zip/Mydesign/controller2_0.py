# waiting to rewrite
# I feel the target is hard to reach
import os
import nnpy
import struct
import subprocess
from scapy.all import Ether, sniff, Packet, BitField, raw

from p4utils.utils.helper import load_topo
from p4utils.utils.sswitch_p4runtime_API import SimpleSwitchP4RuntimeAPI
from p4utils.utils.sswitch_thrift_API import SimpleSwitchThriftAPI

rate = 1
class CpuHeader(Packet):
    name = 'CpuHeader'
    #define a filed to read out our packet from pdp

    # fields_desc = [BitField('countereth',0,16), BitField('counterip', 0, 16),BitField('countertcp',0,16), BitField('counterudp', 0, 16),BitField('counterhttp', 0, 16),BitField('counterdns',0,16), BitField('counterothers', 0, 16),\
    # BitField('protocol',0,8),BitField('dstAddr',0,8),BitField('srcAddr',0,8),BitField('dstPort',0,8),BitField('srcPort',0,8)]

class L3Controller:
    def __init__(self):
        if not os.path.exists('topology.json'):
            print('Could not find topology object!!!\n')
            raise Exception
        self.topo = load_topo('topology.json')
        self.controllers = {}
        self.portnum=[80,53,20,23,25]
        # self.portnum=[0x50,0x35,0x15,0x14,0x17,0x19]
        # self.protonum=[0x1,0x6,0x11,0x58,0x59]
        self.protonum=[1,6,17]
        self.init()
    def init(self):
        self.connect_to_switches()
        self.reset_states()
        self.set_table_defaults()


    def reset_states(self):
        """Resets registers, tables, etc.
        """
        for p4rtswitch, controller in self.controllers.items():
            # Reset grpc server
            controller.reset_state()

            # Connect to thrift server
            thrift_port = self.topo.get_thrift_port(p4rtswitch)
            controller_thrift = SimpleSwitchThriftAPI(thrift_port)
            # Reset forwarding states
            controller_thrift.reset_state()

    def connect_to_switches(self):
        for p4rtswitch, data in self.topo.get_p4switches().items():#it the same ability without the items()functin
            device_id = self.topo.get_p4switch_id(p4rtswitch)
            grpc_port = self.topo.get_grpc_port(p4rtswitch)
            p4rt_path = data['p4rt_path']
            json_path = data['json_path']
            sw_data = self.topo.get_p4rtswitches()[p4rtswitch]
            cpu_port = self.topo.get_cpu_port_index(p4rtswitch)
            self.controllers[p4rtswitch] = SimpleSwitchP4RuntimeAPI(device_id, grpc_port,
                                                                    p4rt_path=p4rt_path,
                                                                    json_path=json_path)
            if cpu_port:
                self.controllers[p4rtswitch].cs_create(100,[cpu_port])


# it is the method to connect many psw,and we should know extractly between psws

    def set_table_defaults(self):
        for controller in self.controllers.values():
            controller.table_set_default("forward", "NoAction", [])
            controller.table_set_default("drop_wrpacket", "drop", [])

    def route(self):

        psw_dict = {sw_name:{} for sw_name in self.topo.get_p4switches().keys()}
        # self.controllers['s1'].table_add("forward", "nexthop", ["0Xb2000001"], ["1","0x0001", "0"])
        # self.controllers['s2'].table_add("forward", "nexthop", ["0Xb2000001"], ["2","0x0008", "3"])
        for sw_name ,controller in self.controllers.items():

            #

            #
            for num1 in self.protonum:
                # if num1 == 0x06 or num1 == 0x11:
                if num1 == 6 or num1 == 17:
                    for num2 in self.portnum:
                        self.controllers[sw_name].table_add("drop_wrpacket","NoAction",["0X0A000001/24",str(num1),str(num2),str(num2)])
                        self.controllers[sw_name].table_add("drop_wrpacket","NoAction",["0Xb2000001/32",str(num1),str(num2),str(num2)])

                else:
                    self.controllers[sw_name].table_add("drop_wrpacket","NoAction",["0X0A000001/24",str(num1),str(0x00),str(0x00)])
                    self.controllers[sw_name].table_add("drop_wrpacket","NoAction",["0Xb2000001/32",str(num1),str(0x00),str(0x00)])

            for sw_dst in self.topo.get_p4switches():

                if sw_name == sw_dst:
                    # one table is well
                    # waiting the drop rulers add

                    for host in self.topo.get_hosts_connected_to(sw_name):
                        sw_port = self.topo.node_to_node_port_num(sw_name, host)
                        host_ip = self.topo.get_host_ip(host)
                        host_mac = self.topo.get_host_mac(host)

                        # add rulers
                        if sw_name == 's1' :
                            # print("table_add at {}:".format(sw_name))
                            self.controllers[sw_name].table_add("forward", "nexthop", [str(host_ip)], ["1",str(host_mac), str(sw_port)])
                        elif sw_name == 's2':
                            # print("table_add at {}:".format(sw_name))
                            self.controllers[sw_name].table_add("forward", "nexthop", [str(host_ip)], ["2",str(host_mac), str(sw_port)])
                        else :
                            pass

                else:
                    if self.topo.get_hosts_connected_to(sw_dst):
                        paths = self.topo.get_shortest_paths_between_nodes(sw_name, sw_dst)
                        for host in self.topo.get_hosts_connected_to(sw_dst):

                            if len(paths) >= 1:
                                next_hop = paths[0][1]

                                host_ip = self.topo.get_host_ip(host)

                                sw_port = self.topo.node_to_node_port_num(sw_name, next_hop)
                                host_mac = self.topo.node_to_node_mac(next_hop, sw_name)

                                #add rule
                                if sw_name == 's1' :
                                    # print("table_add at {}:".format(sw_name))
                                    # print("rightwork but no all work")
                                    self.controllers[sw_name].table_add("forward", "nexthop", [str(host_ip)], ["1",str(host_mac), str(sw_port)])
                                elif sw_name == 's2':
                                    # print("table_add at {}:".format(sw_name))
                                    self.controllers[sw_name].table_add("forward", "nexthop", [str(host_ip)], ["2",str(host_mac), str(sw_port)])


            # if the method is right ,we can recell the function in the function use a loop

    def backrate(self,rate):
        print("right")
        # name = []
        # total = rate[0]
        #     #  send the packet especially the num of esch nextProtocol
        # # the algorithm to choose the most
        # # it should own a quite many packets to
        # countertcp =rate[1]
        # counterudp =rate[2]#wait to trans a value to it
        # counterhttp =rate[3]
        # counterdns =rate[4]
        # counterothers = rate[5]#maybe we don't need deal with it like this
        # if(countertcp>counterudp):
        #     rate[0] = countertcp /total
        #     name[0] = 'tcpmain catch tcp'
        # else :
        #     rate[0] = counterudp /total
        #     name[0] = 'udpmain catch udp'
        # if name[1]== 'httpser':
        #     if rate[1]*0.8 <= counterhttp/total<= rate[1]*1.2 :
        #         name[1]='right';
        #     else :
        #         if counterdns>counterhttp and counterdns>counterothers:
        #             rate[1] = counterdns/toal
        #             name = 'dnsmain noright'
        #         elif rate[1]>1.2:
        #             name = 'noright,but still the same protocol as the last one'
        # elif  name[1]=='dnsser' :
        #     if rate[1]*0.8 <= counterdns/total<= rate[1]*1.2 :
        #         name[1]='right';
        #     else :
        #         if counterhttp>counterdns and counterhttp>counterothers:
        #             rate[1] = counterhttp/toal
        #             name[1] = 'httpmain noright'
        #         elif rate[1]>1.2:
        #             name[1] = 'noright,but still the same protocol as the last one'
        # print(name)
    def config_digest(self):
        # Up to 10 digests can be sent in a single message. Max timeout set to 1 ms.
        self.controllers['s1'].digest_enable('send_t', 1000000, 1, 1000000)

    def unpack_digest(self, dig_list):
        rate = []
        i = 0
        print(dig_list.data)
        for dig in dig_list.data:
            if i<7:
                getrate = int.from_bytes(dig.struct.members[i].bitstring, byteorder='big')
                print(getrate,i)
                rate.append(int(getrate))
                i=i+1
            else:
                outpri=int.from_bytes(dig.struct.members[i].bitstring, byteorder='big')
                print(outpri)
                i=i+1

        return rate


    def run_digest_loop(self):
        self.config_digest()
        while True:
            dig_list = self.controllers['s1'].get_digest_list()

            self.recv_msg_digest(dig_list)


    def recv_msg_digest(self, dig_list):
        learning_data = self.unpack_digest(dig_list)
        self.backrate(learning_data)

    def main(self,name):
        if name == 's1':
            self.route()
        self.run_digest_loop()

if __name__ == "__main__":

    import sys
    sw_name = sys.argv[1]
    controller = L3Controller().main(sw_name)
