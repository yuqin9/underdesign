from scapy.all import *
import argparse
import socket
import sys
import http.client
import ftplib
import telnetlib
import random

def receive():
    print("enter the number of each protocol\n")
    print("the packet will total average send to the dnsser,webser,and other ports\n")
    print("in the part the apply level protocol num will allow the rate to tcp and udp protocol")
    user_input=input("Http:   DNS:   FTP:   Telnet:   SMTP:   \n")
    values = user_input.split()

    num=[int(value) for value in values]
    rate = float(input("rate:   \n"))

    send_random_traffic(num,rate)

def get_if():
    ifs=get_if_list()
    iface=None # "h1-eth0"
    for i in get_if_list():
        if "eth0" in i:
            iface=i
            break
    if not iface:
        print("Cannot find eth0 interface")
        exit(1)
    return iface

def send_random_traffic(num,rate):
    portflag=(80,53,20,23,25)
    ipadd = ('10.0.0.8','10.0.0.3','10.0.0.2','10.0.0.7','10.0.0.6')
    iface = get_if()
    for ip in ipadd:
        for i in range(5):
            dst_addr = socket.gethostbyname(ip)
            total_pkts = 0
            random_port = portflag[i]

    #For this exercise the destination mac address is not important. Just ignore the value we use.
            tp = Ether(dst="00:00:00:00:00:02", src=get_if_hwaddr(iface)) / IP(dst=ip)
            dp = Ether(dst="00:00:00:00:00:02", src=get_if_hwaddr(iface)) / IP(dst=ip)
            for j in range(int(num[i]*rate)):
                tp = tp / TCP(sport=random_port, dport=random_port)
                sendp(tp, iface = iface)
                total_pkts += 1
                print("Sent %s packets in tcp" % total_pkts)
            for j in range(int(num[i]*(1-rate))):
                dp = dp / UDP(sport=random_port, dport=random_port)
                sendp(dp, iface = iface)
                total_pkts += 1
                print("Sent %s packets in udp" % total_pkts)

if __name__ == '__main__':
    receive()
