# waiting to rewrite
# I feel the target is hard to reach
import os
import nnpy
import struct
from scapy.all import Ether, sniff, Packet, BitField, raw

from p4utils.utils.helper import load_topo
from p4utils.utils.sswitch_p4runtime_API import SimpleSwitchP4RuntimeAPI
from p4utils.utils.sswitch_thrift_API import SimpleSwitchThriftAPI

rate = 1
class CpuHeader(Packet):
    name = 'CpuHeader'
    #define a filed to read out our packet from pdp

    fields_desc = [BitField('countereth',0,16), BitField('counterip', 0, 16),BitField('countertcp',0,16), BitField('counterudp', 0, 16),BitField('counterhttp', 0, 16),BitField('counterdns',0,16), BitField('counterothers', 0, 16),\
    BitField('protocol',0,8),BitField('dstAddr',0,8),BitField('srcAddr',0,8),BitField('dstPort',0,8),BitField('srcPort',0,8)]

class L3Controller:
    def __init__(self):
        if not os.path.exists('topology.json'):
            print('Could not find topology object!!!\n')
            raise Exception
        self.topo = load_topo('topology.json')
        self.controllers = {}
        self.init()
    def init(self):
        self.connect_to_switches()
        self.reset_states()
        self.set_table_defaults()

    def reset_states(self):
        """Resets registers, tables, etc.
        """
        for p4rtswitch, controller in self.controllers.items():
            # Reset grpc server
            controller.reset_state()

            # Connect to thrift server
            thrift_port = self.topo.get_thrift_port(p4rtswitch)
            controller_thrift = SimpleSwitchThriftAPI(thrift_port)
            # Reset forwarding states
            controller_thrift.reset_state()

    def connect_to_switches(self):
        for p4rtswitch, data in self.topo.get_p4switches().items():#it the same ability without the items()functin
            device_id = self.topo.get_p4switch_id(p4rtswitch)
            grpc_port = self.topo.get_grpc_port(p4rtswitch)
            p4rt_path = data['p4rt_path']
            json_path = data['json_path']
            self.controllers[p4rtswitch] = SimpleSwitchP4RuntimeAPI(device_id, grpc_port,
                                                                    p4rt_path=p4rt_path,
                                                                    json_path=json_path)
            print("AAAAAAAAAAAAAAA")
            print(self.topo.get_p4switches().keys())
            print("AAAAAAAAAAAAAAA")
# it is the method to connect many psw

    def set_table_defaults(self):
        for controller in self.controllers.values():
            controller.table_set_default("forward", "drop", [])
            controller.table_set_default("tdrop_wrpacket", "NoAction", [])

    def route(self):
        name = 'NoName'
        rate = backrate(rate,name)
        psw_dict = {sw_name:{} for sw_name in self.topo.get_p4switches().keys()}
        print("BBBBBBBBBBBBBBB")
        print(psw_dict)
        print("BBBBBBBBBBBBBBB")
        for sw_name ,controller in self.controllers.items():
            for sw_dst in self.topo.get_p4switches():
                if sw_name == sw_dst:
                    self.controllers[sw_name].table_add("tdrop_wrpacket", "NoAction", ["10.0.0.1/24","0x50","0x50","6"], [])
                    self.controllers[sw_name].table_add("tdrop_wrpacket", "NoAction", ["10.0.0.1/24","0x35","0x35","6"], [])
                    self.controllers[sw_name].table_add("tdrop_wrpacket", "NoAction", ["10.0.0.1/24","0x19","0x19","6"], [])
                    self.controllers[sw_name].table_add("tdrop_wrpacket", "NoAction", ["10.0.0.1/24","0x17","0x17","6"], [])
                    self.controllers[sw_name].table_add("tdrop_wrpacket", "NoAction", ["10.0.0.1/24","0x14","0x14","6"], [])
                    self.controllers[sw_name].table_add("tdrop_wrpacket", "NoAction", ["10.0.0.1/24","0x15","0x15","6"], [])
                    self.controllers[sw_name].table_add("udrop_wrpacket", "NoAction", ["10.0.0.1/24","0x50","0x50","17"], [])
                    self.controllers[sw_name].table_add("udrop_wrpacket", "NoAction", ["10.0.0.1/24","0x35","0x35","17"], [])
                    self.controllers[sw_name].table_add("udrop_wrpacket", "NoAction", ["10.0.0.1/24","0x19","0x19","17"], [])
                    self.controllers[sw_name].table_add("udrop_wrpacket", "NoAction", ["10.0.0.1/24","0x17","0x17","17"], [])
                    self.controllers[sw_name].table_add("udrop_wrpacket", "NoAction", ["10.0.0.1/24","0x14","0x14","17"], [])
                    self.controllers[sw_name].table_add("udrop_wrpacket", "NoAction", ["10.0.0.1/24","0x15","0x15","17"], [])
                    for host in self.topo.get_hosts_connected_to(sw_name):
                        sw_port = self.topo.node_to_node_port_num(sw_name, host)
                        host_ip = self.topo.get_host_ip(host) + "/24"
                        host_mac = self.topo.get_host_mac(host)
                        # add rulers
                        if sw_name == 'S1' :
                            print("table_add at {}:".format(sw_name))
                            self.controllers[sw_name].table_add("forward", "nexthop", [str(host_ip)], ["0001",str(host_mac), str(sw_port)])
                        elif sw_name == 'S2':
                            print("table_add at {}:".format(sw_name))
                            self.controllers[sw_name].table_add("forward", "nexthop", [str(host_ip)], ["0002",str(host_mac), str(sw_port)])
                        else :
                            pass
    def recv_msg_cpu(self, pkt):
        packet = Ether(raw(pkt))
        if packet.type == 0x1234:
            cpu_header = CpuHeader(bytes(packet.load))
            # in the function we get the info from thr cpupak
            print("11111111111")
            print(cpu_header[0])
            print("11111111111")
            # if the method is right ,we can recell the function in the function use a loop

    def backrate(rate,*name):
        total = countereth
            #  send the packet especially the num of esch nextProtocol
        # the algorithm to choose the most
        countertcp =0
        counterudp =0#wait to trans a value to it
        counterhttp =0
        counterdns =0
        counterothers = 0#maybe we don't need deal with it like this
        if(countertcp>counterudp):
            rate[0] = countertcp /total
            name[0] = 'tcpmain'
        else :
            rate[0] = counterudp /total
            name[0] = 'udpmain'
        if name[1]== 'httpser':
            if rate[1]*0.8 <= counterhttp/total<= rate[1]*1.2 :
                name[1]='right';
            else :
                if counterdns>counterhttp and counterdns>counterothers:
                    rate[1] = counterdns/toal
                    name = 'dnsmain noright'
                elif rate[1]>1.2:
                    name = 'noright,but still the same protocol as the last one'
        elif  name[1]=='dnsser' :
            if rate[1]*0.8 <= counterdns/total<= rate[1]*1.2 :
                name[1]='right';
            else :
                if counterhttp>counterdns and counterhttp>counterothers:
                    rate[1] = counterhttp/toal
                    name = 'httpmain noright'
                elif rate[1]>1.2:
                    name = 'noright,but still the same protocol as the last one'

    def run_cpu_port_loop(self):
        cpu_port_intf = str(self.topo.get_cpu_port_intf(self.sw_name).replace("eth10", "eth11"))
        print("11111111111")
        print(cpu_port_intf)
        print("11111111111")
        sniff(iface=cpu_port_intf, prn=self.recv_msg_cpu)

    def main(self):
        self.route()


if __name__ == "__main__":
    controller = L3Controller().main()
